<body class="inf-body">
    <?php
    require "header.php";
    ?>
    <div class="title">
        О нас
    </div>
    <div class="flexarea">
    <div class="flex-point" id="point1">
        <div class="point" id="point1">
            <div class="point-title">
                На рынке уже 10 лет
            </div>
            <div class="point-text">
                Наша компания находится на рынке продажи компьютеров уже 10 лет
            </div>
        </div>
        <div class="photo-point">
            <img src="images/background1.jpg" alt="dsdffasd">
        </div>
    </div>
        <div class="flex-point" id="point2">
            <div class="photo-point">
                <img src="images/background2.jpg" alt="dsdffasd">
            </div>
            <div class="point">
                <div class="point-title">
                    Специалисты
                </div>
                <div class="point-text">
                    В нашей компании работают только опытные специалисты с большим опытом
                </div>
                
            </div>
        </div>
    </div>
    <?php
    require "footer.php";
    ?>
</body>

</html>